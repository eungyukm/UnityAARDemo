# UnityAARDemo
요구 사항
1. AndroidStudio 2020.3.1 Patch 2
2. Android Gradle Plugin Version : 7.0.2
3. Gradle Version : 7.0.2
4. Unity 2020.3.14f1
